import json
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('contactMessages')

def lambda_handler(event, context):
    # Log the incoming event to ensure data is received
    print("Received event: ", event)
    
    try:
        # Parse the body of the request
        body = json.loads(event['body'])
        
        # Log the parsed body to check the values
        print("Parsed body: ", body)

        # Ensure required fields are present
        if 'email' not in body or 'name' not in body or 'message' not in body:
            raise ValueError("Missing required fields in request body")

        # Store the data in DynamoDB
        table.put_item(Item={
            'email': body['email'],
            'timestamp': datetime.utcnow().isoformat(),
            'name': body['name'],
            'message': body['message']
        })

        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST'
            },
            'body': json.dumps({'message': 'Submission successful'})
        }

    except Exception as e:
        # Log the error to help debug
        print(f"Error occurred: {str(e)}")

        # Return error response
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST'
            },
            'body': json.dumps({'message': 'Error occurred', 'error': str(e)})
        }


